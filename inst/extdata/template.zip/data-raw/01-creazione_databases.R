#################################################
# Creazione databases e tabelle in MySQL server #
#################################################

library(masteRfun)

dbn <- 'inserire-qui-il-nome-database'
crea_db(dbn)

## TABELLA <nome_tabella> ----------------
x <- "
    `` INT UNSIGNED AUTO_INCREMENT NOT NULL,
    `` CHAR(12) NOT NULL,
    `` CHAR(7) NULL DEFAULT NULL,
    `` VARCHAR(50) NOT NULL,
    `` DECIMAL(10,8) NOT NULL,
    `` TINYINT UNSIGNED NOT NULL,
    PRIMARY KEY (``, ``),
    UNIQUE KEY `nome_key` (``),
    KEY `nome_key` (``)
"
crea_tabella_db(dbn, 'nome_tabella', x)


## FINE -------------------------------
rm(list = ls())
gc()
