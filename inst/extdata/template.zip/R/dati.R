#' @importFrom data.table data.table
NULL

#' nome_tabella
#'
#' Descrizione ...
#' 
#' @format Una data.table con i campi seguenti:
#' \describe{
#'   \item{\code{nome_campo}}{ descrizione_campo }
#'   \item{\code{}}{  }
#'   \item{\code{}}{  }
#'   \item{\code{}}{  }
#' }
#'
'etichette'


#' @import sf
NULL

#' nome_oggetto
#'
#' Poligoni geografici ... (al Marzo 2021). 
#'
#' Maggiori informazioni possono essere reperite nelle tabelle \code{comuni} e \code{zone} del pacchetto \code{masteRgeo}.
#'
#' Per ulteriori dettagli, consultare il sito ISTAT \url{https://www.istat.it/it/archivio/104317}
#'
'nome_oggetto'

