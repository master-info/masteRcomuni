#' Lista di ????
#'
#' @export
nomelista.lst <- c('')


# .onLoad <- function(libname, pkgname) {
#
# }

# .onAttach <- function(libname, pkgname) {
#     packageStartupMessage(
#     )
# }
